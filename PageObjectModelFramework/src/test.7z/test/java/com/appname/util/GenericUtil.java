package com.appname.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class GenericUtil {
	
	public static String getExcelData(String filePath, String sheetName, int rowIndex, int CellIndex) {
		String data=null;
		try {
			File f = new File(filePath);

			FileInputStream fis = new FileInputStream(f);

			Workbook wb = WorkbookFactory.create(fis);

			Sheet sh = wb.getSheet(sheetName);

			Row r = sh.getRow(rowIndex);

			Cell c=r.getCell(CellIndex);

			data = c.toString();

		} catch (Exception e) {

		}
		return data;
	}

	
	public static String setExcelData(String filePath, String sheetName, int rowIndex, int CellIndex, String data) {
		
		try {
			File f = new File(filePath);

			FileInputStream fis = new FileInputStream(f);

			Workbook wb = WorkbookFactory.create(fis);

			Sheet sh = wb.getSheet(sheetName);

			Row r = sh.createRow(rowIndex);

			Cell c = r.createCell(CellIndex);
			
			c.setCellValue(data);
			
			FileOutputStream fos=new FileOutputStream(f);
			
			wb.write(fos);

		} catch (Exception e) {

		}
		return data;
	}
	
	public static ArrayList<String> getOptions(WebElement ddl) {
		ArrayList<String> arr = new ArrayList<String>();
		Select sct = new Select(ddl);
		List<WebElement> options = sct.getOptions();
		for (int i = 0; i < options.size(); i++) {
			arr.add(options.get(i).getText());
		}

		return arr;
	}

	public static ArrayList<String> getAllSelectedOptions(WebElement ddl) {
		ArrayList<String> arr = new ArrayList<String>();
		Select sct = new Select(ddl);
		List<WebElement> options = sct.getAllSelectedOptions();
		for (int i = 0; i < options.size(); i++) {
			arr.add(options.get(i).getText());
		}

		return arr;
	}

	public static void selectParticularOption(WebElement ddl, String optionVisibleText) {

		Select sct = new Select(ddl);
		List<WebElement> options = sct.getOptions();
		for (int i = 0; i < options.size(); i++) {
			String str = options.get(i).getText();
			if (str.equals(optionVisibleText)) {
				sct.selectByVisibleText(optionVisibleText);
				break;
			}
		}

	}

	public static void selectDDLByIndex(WebElement ddl, int optionIndex) {
		Select sct = new Select(ddl);

		sct.selectByIndex(optionIndex);
	}

	public static void selectDDLByValue(WebElement ddl, String optionValue) {
		Select sct = new Select(ddl);

		sct.selectByValue(optionValue);
	}

	public static void selectDDLByVisibleText(WebElement ddl, String optionVisibleText) {
		Select sct = new Select(ddl);

		sct.selectByVisibleText(optionVisibleText);
	}

	public static void deselectDDLByIndex(WebElement ddl, int optionIndex) {
		Select sct = new Select(ddl);

		sct.deselectByIndex(optionIndex);
	}

	public static void deselectDDLByValue(WebElement ddl, String value) {
		Select sct = new Select(ddl);

		sct.deselectByValue(value);
	}

	public static void deselectDDLByVisibleText(WebElement ddl, String visibleText) {
		Select sct = new Select(ddl);

		sct.deselectByVisibleText(visibleText);
	}

	public static void deselectAllinDDL(WebElement ddl) {
		Select sct = new Select(ddl);

		sct.deselectAll();
	}

	public static void moveToElement(WebDriver driver, WebElement menuItem) {
		Actions act = new Actions(driver);
		act.moveToElement(menuItem).perform();

	}

	public static void rightClick(WebDriver driver, WebElement element) {
		Actions act = new Actions(driver);
		act.contextClick(element).perform();
	}

	public static void doubleClick(WebDriver driver, WebElement element) {
		Actions act = new Actions(driver);
		act.doubleClick(element).perform();
	}

	public static void dragAndDrop(WebDriver driver, WebElement srcElement, WebElement destElement) {
		Actions act = new Actions(driver);
		act.dragAndDrop(srcElement, destElement).perform();
		// act.moveToElement(srcElement).clickAndHold().moveToElement(destElement).release().build().perform();;
	}

	
	public static void acceptAlert(WebDriver driver)
	{
		Alert alt=driver.switchTo().alert();
		alt.accept();
	}
	
	public static void dismissAlert(WebDriver driver)
	{
		Alert alt=driver.switchTo().alert();
		alt.dismiss();
	}
	
	public static String getAlertMsg(WebDriver driver)
	{
		Alert alt=driver.switchTo().alert();
		String alert_msg=alt.getText();
		return alert_msg;
	}
	
	public static void enterTextOnAlert(WebDriver driver, String text)
	{
		Alert alt= driver.switchTo().alert();
		alt.sendKeys(text);
	}

}
