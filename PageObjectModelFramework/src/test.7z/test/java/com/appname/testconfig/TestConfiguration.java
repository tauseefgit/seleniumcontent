package com.appname.testconfig;

import org.testng.annotations.BeforeClass;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.TimeUnit;

//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.io.Zip;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeSuite;
import com.appname.util.GenericUtil;

import org.testng.annotations.AfterSuite;

public class TestConfiguration {

	public WebDriver driver;
	public String url;

	@BeforeClass
	public void beforeClass() {
		String browserName = GenericUtil.getExcelData("./data/TestData.xlsx", "Config", 1, 0);
		url = GenericUtil.getExcelData("./data/TestData.xlsx", "Config", 1, 1);

		if (browserName.equalsIgnoreCase("ff")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("gc")) {
			System.setProperty("webdriver.chrome.driver", "./browser_exe/chromedriver.exe");
			driver = new ChromeDriver();
		} else {
			System.setProperty("webdriver.ie.driver", "./browser_exe/IEDriverServer.exe");
			driver = new InternetExplorerDriver();
		}
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(url);
	}

	@AfterClass
	public void afterClass() {
		driver.close();
	}
	

	@BeforeSuite
	public void beforeSuite() {
		Date d = new Date();
		String date = d.toString().replace(":", "_");
		File filetoStore = new File("./test-output");
		if (filetoStore.exists()) {
			File filetoCompress = new File("./result_archive/" + date + ".zip");
			Zip z = new Zip();
			try {
				z.zip(filetoStore, filetoCompress);
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

	@AfterSuite
	public void afterSuite() {
		/*
		 * File filetoDelete = new File("./temp"); try {
		 * FileUtils.deleteDirectory(filetoDelete); } catch (IOException e) {
		 * 
		 * e.printStackTrace(); }
		 */
	}

}
